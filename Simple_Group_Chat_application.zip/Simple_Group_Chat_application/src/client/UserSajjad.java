package client;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class UserSajjad implements ActionListener, Runnable {

    String out;
    JTextField text;
    JScrollPane scrollPane;
    JPanel conversationPart;
    static Box vertical = Box.createVerticalBox();
    static JFrame mainFrame = new JFrame();
    static DataOutputStream dout;
    JButton sendButton, emojiButton, imageButton;

    BufferedReader reader;
    BufferedWriter writer;
    String name = "Sajjad Khan";

    UserSajjad() {
        mainFrame.setLayout(null);

        JPanel headPart = new JPanel();
        headPart.setBackground(new Color(74, 166, 247));
        headPart.setBounds(0, 0, 400, 60);
        headPart.setLayout(null);
        mainFrame.add(headPart);

        JLabel GroupName = new JLabel("212-D1");
        GroupName.setBounds(10, 12, 150, 18);
        GroupName.setForeground(Color.WHITE);
        GroupName.setFont(new Font("Arial", Font.BOLD, 20));
        headPart.add(GroupName);

        JLabel GroupMembers = new JLabel("Sajjad, Arif, Hasib, Rahul, Rifan, Nifat, Prince");
        GroupMembers.setBounds(10, 32, 200, 18);
        GroupMembers.setForeground(Color.WHITE);
        GroupMembers.setFont(new Font("Arial", Font.BOLD, 15));
        headPart.add(GroupMembers);

        ImageIcon hasibImg = new ImageIcon(ClassLoader.getSystemResource("icons/Sajjad.jpg"));
        Image hasibImg1 = hasibImg.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
        ImageIcon hasibImg2 = new ImageIcon(hasibImg1);
        JLabel profile = new JLabel(hasibImg2);
        profile.setBounds(270, 6, 50, 50);
        headPart.add(profile);

        ImageIcon stop = new ImageIcon(ClassLoader.getSystemResource("icons/stop.png"));
        Image stop2 = stop.getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT);
        ImageIcon stop3 = new ImageIcon(stop2);

        JLabel close = new JLabel(stop3);
        close.setBounds(350, 8, 45, 45);
        headPart.add(close);

        close.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent ae) {
                System.exit(0);
            }
        });

        conversationPart = new JPanel();
        conversationPart.setBackground(new Color(239, 239, 239));
        scrollPane = new JScrollPane(conversationPart);
        scrollPane.setBounds(0, 60, 400, 500);
        mainFrame.add(scrollPane);

        text = new JTextField();
        text.setBounds(0, 560, 250, 40);
        text.setBackground(new Color(246, 246, 246));
        text.setFont(new Font("Arial", Font.PLAIN, 15));
        mainFrame.add(text);

        ImageIcon imageImg = new ImageIcon(ClassLoader.getSystemResource("icons/image_1.png"));
        Image imageImg1 = imageImg.getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT);
        ImageIcon imageImg2 = new ImageIcon(imageImg1);

        imageButton = new JButton(imageImg2);
        imageButton.setBounds(260, 560, 40, 40);
        imageButton.addActionListener(this);
        mainFrame.add(imageButton);

        ImageIcon emojiImg = new ImageIcon(ClassLoader.getSystemResource("icons/smile-wink.png"));
        Image emojiImg1 = emojiImg.getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT);
        ImageIcon emojiImg2 = new ImageIcon(emojiImg1);

        emojiButton = new JButton(emojiImg2);
        emojiButton.setBounds(310, 560, 40, 40);
        emojiButton.addActionListener(this);
        mainFrame.add(emojiButton);

        ImageIcon sendImg = new ImageIcon(ClassLoader.getSystemResource("icons/send_1.png"));
        Image sendImg1 = sendImg.getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT);
        ImageIcon sendImg2 = new ImageIcon(sendImg1);

        sendButton = new JButton(sendImg2);
        sendButton.setBounds(360, 560, 40, 40);
        sendButton.addActionListener(this);
        mainFrame.add(sendButton);

        JLabel copyright = new JLabel("Developed By Sajjad Hossen.");
        copyright.setBounds(70, 615, 300, 25);
        copyright.setForeground(Color.white);
        copyright.setFont(new Font("Arial", Font.BOLD, 20));
        mainFrame.add(copyright);

        mainFrame.setSize(400, 650);
        mainFrame.setLocation(860, 30);
        mainFrame.setUndecorated(true);
        mainFrame.getContentPane().setBackground(new Color(74, 166, 247));

        mainFrame.setVisible(true);

        try {
            Socket socket = new Socket("localhost", 500);
            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == sendButton) {
            try {
                String out = "<html><p>" + name + "</p><p>" + text.getText() + "</p></html>";

                JPanel chat = formatLabel(out);

                conversationPart.setLayout(new BorderLayout());

                JPanel right = new JPanel(new BorderLayout());
                right.setBackground(new Color(239, 239, 239));
                right.add(chat, BorderLayout.LINE_END);
                vertical.add(right);
                vertical.add(Box.createVerticalStrut(20));

                conversationPart.add(vertical, BorderLayout.PAGE_START);

                try {
                    writer.write(out);
                    writer.write("\r\n");
                    writer.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                text.setText("");

                mainFrame.repaint();
                mainFrame.invalidate();
                mainFrame.validate();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == emojiButton) {
            try {

                JPopupMenu popupmenu = new JPopupMenu("emoji");

                JMenuItem like = new JMenuItem("👍  ");
                JMenuItem smile = new JMenuItem("😊  ");
                JMenuItem love = new JMenuItem("❤  ");
                JMenuItem tear = new JMenuItem("😢  ");

                popupmenu.add(like);
                popupmenu.add(smile);
                popupmenu.add(love);
                popupmenu.add(tear);

                popupmenu.show(mainFrame, 310, 470);

                like.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        out = "&#128077";
                        send(out);
                    }
                });

                smile.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        out = "&#128522";
                        send(out);
                    }
                });
                love.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        out = "&#9829";
                        send(out);
                    }
                });
                tear.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        out = "&#128514";
                        send(out);
                    }
                });

                //String temp = "&#128514";
                //text.setText("out");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == imageButton) {
            try {
          
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Choose an image file");
        
       
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png", "gif");
        fileChooser.setFileFilter(filter);
        
        int userChoice = fileChooser.showOpenDialog(mainFrame);
        
        if (userChoice == JFileChooser.APPROVE_OPTION) {
            // User selected a file
            String imagePath = fileChooser.getSelectedFile().getAbsolutePath();
            sendImage(imagePath);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
           
        }
    }
    private void sendImage(String imagePath) {
    try {
        // Create a label to display the image
        ImageIcon imageIcon = new ImageIcon(imagePath);
        JLabel imageLabel = new JLabel(imageIcon);
        
        imageLabel.setPreferredSize(new Dimension(226,220));

        JPanel chat = new JPanel();
        chat.setLayout(new BorderLayout());
        chat.setBackground(new Color(20, 30, 40));

        // Add the image label to the chat panel
        chat.add(imageLabel, BorderLayout.LINE_END);

        // Add the chat panel to the vertical box
        vertical.add(chat);
        vertical.add(Box.createVerticalStrut(20));
         
        // Write a message to the writer indicating that an image was sent
        writer.write("Image sent: " + imagePath);
        writer.write("\r\n");
        writer.flush();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
        
    

    public void send(String out) {
        text.setText(out);
        
        out = "<html><p>" + name + "</p><p>" + text.getText() + "</p></html>";
        JPanel chat = formatLabel(out);

        conversationPart.setLayout(new BorderLayout());

        JPanel right = new JPanel(new BorderLayout());
        right.setBackground(new Color(239, 239, 239));
        right.add(chat, BorderLayout.LINE_END);
        vertical.add(right);
        vertical.add(Box.createVerticalStrut(20));

        conversationPart.add(vertical, BorderLayout.PAGE_START);

        try {
            writer.write(out);
            writer.write("\r\n");
            writer.flush();
        } catch (IOException ex) {
            System.err.println(ex);
        }

        text.setText("");

        mainFrame.repaint();
        mainFrame.invalidate();
        mainFrame.validate();
    }

    public static JPanel formatLabel(String out) {
        JPanel message = new JPanel();
        message.setBackground(new Color(239, 239, 239));
        message.setLayout(new BoxLayout(message, BoxLayout.Y_AXIS));

        JLabel output = new JLabel("<html><p style=\"width: 150px\">" + out + "</p></html>");
        output.setFont(new Font("Arial", Font.PLAIN, 15));
        output.setBackground(new Color(116, 214, 128));
        output.setForeground(Color.WHITE);
        output.setOpaque(true);
        output.setBorder(new EmptyBorder(10, 15, 10, 15));

        message.add(output);

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

        JLabel time = new JLabel();
        time.setText(sdf.format(cal.getTime()));

        message.add(time);

        return message;
    }

    public void run() {
        try {
            String msg = "";
            while (true) {
                msg = reader.readLine();
                if (msg.contains(name)) {
                    continue;
                }

                conversationPart.setLayout(new BorderLayout());

                JPanel recieveMessage = formatLabel(msg);

                JPanel left = new JPanel(new BorderLayout());
                left.setBackground(new Color(239, 239, 239));
                left.add(recieveMessage, BorderLayout.LINE_START);
                vertical.add(left);

                conversationPart.add(vertical, BorderLayout.PAGE_START);

                mainFrame.repaint();
                mainFrame.invalidate();
                mainFrame.validate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        UserSajjad third = new UserSajjad();
        Thread t1 = new Thread(third);
        t1.start();
    }
}
